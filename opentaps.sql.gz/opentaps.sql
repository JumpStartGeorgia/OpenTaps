-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 08, 2011 at 01:41 PM
-- Server version: 5.1.54
-- PHP Version: 5.3.5-1ubuntu7.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `opentaps`
--

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE IF NOT EXISTS `donors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `don_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `don_desc` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`id`, `don_name`, `don_desc`) VALUES
(2, '4545454', 'vaxaxaxa'),
(5, '44444444444444444444444444444444444444444', '444444444444444444444444444444444444444444124124521421351235 1235 2135 234 235 2352352 3'),
(6, 'adsdasdas', 'dasdsadasdasd'),
(7, 'sdasdasd', 'asdasda'),
(8, 'asdasdasd', 'dasdasdad'),
(9, 'asdasdasd', 'dasdasdad'),
(10, 'asdasdasd', 'dasdasdad');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `short_name` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `parent_id`, `name`, `short_name`) VALUES
(1, 0, 'georgia profile', 'profile'),
(2, 0, 'water issues', 'issues'),
(3, 0, 'projects', 'projects'),
(4, 0, 'organizations', 'org'),
(5, 0, 'statistics', 'stat'),
(6, 0, 'data', 'data'),
(7, 1, 'submenu1', ''),
(8, 1, 'submenu2', ''),
(9, 4, 'organization1', ''),
(10, 4, 'organization2', ''),
(11, 3, 'project1', ''),
(12, 1, 'project2f', '');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `image` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `published_at` varchar(20) NOT NULL,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `news`
--


-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `district` text NOT NULL,
  `city_town` varchar(255) NOT NULL,
  `grante` varchar(255) NOT NULL,
  `sector` varchar(255) NOT NULL,
  `projects_info` text NOT NULL,
  `logo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `name`, `description`, `district`, `city_town`, `grante`, `sector`, `projects_info`, `logo`) VALUES
(40, 'sdfsfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdfsdfsdfsdf', 'sdfsdfsdfsdfsdsd', 'fsdfsdfsdfsdfsdf', 'sdfsdfsdfsdfsdfdsfsdf', ''),
(41, 'sdfdsfsd', 'fsdfsdf', 'sdfsdf', 'sdfsdfsdfsdfsdf', 'sdfsdfsdfsdfsdfsd', 'fsdfsdfsdfsdfsdfsdfsd', 'fsdfsdfsdfsdfsdfsdf', '/var/www/OpenTaps/uploads/organization_photos/191014581313579390Firefox_wallpaper.png');

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE IF NOT EXISTS `places` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `longitude` decimal(20,5) NOT NULL,
  `latitude` decimal(20,5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `region_id` int(10) NOT NULL,
  `raion_id` int(10) NOT NULL,
  `project_id` int(10) NOT NULL,
  `pollution_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`id`, `longitude`, `latitude`, `name`, `region_id`, `raion_id`, `project_id`, `pollution_id`) VALUES
(64, '234.23423', '324234.23423', 'ika', 1, 0, 0, 0),
(60, '4897809.19086', '5231598.57487', 'java', 0, 0, 6, 0),
(61, '4980666.92951', '5128102.83859', 'tbilisi', 0, 0, 7, 0),
(70, '234523423423423.23432', '234324.23426', 'irakli123', 7, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `budget` int(10) NOT NULL,
  `region_id` int(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `grantee` varchar(255) NOT NULL,
  `sector` varchar(255) NOT NULL,
  `start_at` date NOT NULL,
  `end_at` date NOT NULL,
  `info` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `place_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `description`, `budget`, `region_id`, `city`, `grantee`, `sector`, `start_at`, `end_at`, `info`, `type`, `place_id`) VALUES
(15, 'irakli', 'idsfnsdkjfsdf', 3234324, 0, 'fsdfsdf', 'sdfsdfdsf', 'sdfsdfsdfdsfds', '2005-03-05', '2006-04-03', 'dfsdjkfsdf', 'infrastructure', 64);

-- --------------------------------------------------------

--
-- Table structure for table `projects_data`
--

CREATE TABLE IF NOT EXISTS `projects_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `projects_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `project_organizations`
--

CREATE TABLE IF NOT EXISTS `project_organizations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) NOT NULL,
  `organization_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `project_organizations`
--

INSERT INTO `project_organizations` (`id`, `project_id`, `organization_id`) VALUES
(21, 15, 41);

-- --------------------------------------------------------

--
-- Table structure for table `raions`
--

CREATE TABLE IF NOT EXISTS `raions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `region_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `raions`
--

INSERT INTO `raions` (`id`, `name`, `region_id`) VALUES
(1, 'dsfsdfsdf', 1),
(2, 'dfsfsdfsdfsdgffgdfgdfg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE IF NOT EXISTS `regions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `region_info` text NOT NULL,
  `projects_info` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `population` int(10) NOT NULL,
  `square_meters` int(10) NOT NULL,
  `settlement` varchar(255) NOT NULL,
  `villages` int(10) NOT NULL,
  `districts` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`, `region_info`, `projects_info`, `city`, `population`, `square_meters`, `settlement`, `villages`, `districts`) VALUES
(7, 'ika', 'sdfsdfsd', 'fsdfsdfsd', 'sdfsdfsdf', 2234234, 5434534, 'dgdfg', 32424, 324423),
(6, 'sdfsdf', 'sdfsdf', 'sdfsdfsd', 'sdfsdf', 3435, 354, 'sdfsdf', 453, 435);

-- --------------------------------------------------------

--
-- Table structure for table `region_cordinates`
--

CREATE TABLE IF NOT EXISTS `region_cordinates` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `longitude` decimal(20,5) NOT NULL,
  `latitude` decimal(20,5) NOT NULL,
  `region_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `region_cordinates`
--

INSERT INTO `region_cordinates` (`id`, `longitude`, `latitude`, `region_id`) VALUES
(1, '4636700.30229', '5109299.32963', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`) VALUES
(1, 'lorem'),
(2, 'ipsum'),
(3, 'dolor'),
(4, 'sit'),
(5, 'amet'),
(6, 'consectetur'),
(9, 'vaxaxa3'),
(10, 'tag#');

-- --------------------------------------------------------

--
-- Table structure for table `tag_connector`
--

CREATE TABLE IF NOT EXISTS `tag_connector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `proj_id` int(11) DEFAULT NULL,
  `news_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=216 ;

--
-- Dumping data for table `tag_connector`
--

INSERT INTO `tag_connector` (`id`, `tag_id`, `org_id`, `proj_id`, `news_id`) VALUES
(215, 9, NULL, 15, NULL),
(214, 6, NULL, 15, NULL),
(99, 10, 2, 0, 0),
(98, 9, 2, 0, 0),
(97, 6, 2, 0, 0),
(96, 5, 2, 0, 0),
(95, 4, 2, 0, 0),
(94, 3, 2, 0, 0),
(93, 1, 2, 0, 0),
(68, 9, 9, 0, 0),
(67, 1, 9, 0, 0),
(92, 10, 13, 0, 0),
(91, 9, 13, 0, 0),
(90, 6, 13, 0, 0),
(213, 4, NULL, 15, NULL),
(212, 2, NULL, 15, NULL),
(108, 2, 40, NULL, NULL),
(109, 3, 40, NULL, NULL),
(110, 4, 40, NULL, NULL),
(156, 6, NULL, 0, NULL),
(155, 3, NULL, 0, NULL),
(117, 6, 41, NULL, NULL),
(154, 2, NULL, 0, NULL),
(153, 1, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'vazha', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8'),
(2, 'client', '2736fab291f04e69b62d490c3c09361f5b82461a'),
(6, 'ika', 'e34a2da1437adaf97ada8a7b4c52f2555a9b26dc');
