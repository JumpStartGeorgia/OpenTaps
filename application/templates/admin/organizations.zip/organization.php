<div class='projects_organization'>
                PROJECTS ORGANIZATION
            </div>

            <div class='spacer'>
            </div>
<div class='news'>
    <!--<img src='<?php echo URL ?>images/news.jpg' />-->
    <p style="margin-left:10px;">Organization</p>
</div>
<div class="news_body"><?php
        echo "<div><center><h2>" . $organization['org_name'] . "</h2></center></div>";
        echo "<div><blockquote>" . $organization['org_description'] . "</blockquote></div>";
?></div>


<div id="chart" class='chart'>
  <!--<center>
   <img src='images/chart.jpg' />
  </center>-->
</div>
