-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 18, 2011 at 01:00 PM
-- Server version: 5.1.54
-- PHP Version: 5.3.5-1ubuntu7.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `opentaps`
--
CREATE DATABASE `opentaps` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `opentaps`;

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE IF NOT EXISTS `donors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `don_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `don_desc` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`id`, `don_name`, `don_desc`) VALUES
(2, '4545454', 'vaxaxaxa'),
(5, '44444444444444444444444444444444444444444', '444444444444444444444444444444444444444444124124521421351235 1235 2135 234 235 2352352 3'),
(6, 'adsdasdas', 'dasdsadasdasd'),
(7, 'sdasdasd', 'asdasda'),
(8, 'asdasdasd', 'dasdasdad'),
(9, 'asdasdasd', 'dasdasdad'),
(10, 'asdasdasd', 'dasdasdad');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `short_name` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `parent_id`, `name`, `short_name`) VALUES
(1, 0, 'georgia profile', 'profile'),
(2, 0, 'water issues', 'issues'),
(3, 0, 'projects', 'projects'),
(4, 0, 'organizations', 'org'),
(5, 0, 'statistics', 'stat'),
(6, 0, 'data', 'data'),
(7, 1, 'submenu1', ''),
(8, 1, 'submenu2', ''),
(9, 4, 'organization1', ''),
(10, 4, 'organization2', ''),
(11, 3, 'project1', ''),
(12, 1, 'project2f', ''),
(25, 3, 'lorem', ''),
(26, 3, 'ipsum', ''),
(27, 3, 'dolor', ''),
(28, 3, 'sit', ''),
(29, 3, 'amet', ''),
(30, 3, 'consectetur', ''),
(31, 3, 'adipisicing', ''),
(32, 3, 'elit', ''),
(33, 3, 'sed', ''),
(34, 3, 'do', ''),
(35, 3, 'eiusmod', ''),
(36, 3, 'tempor', ''),
(37, 3, 'gogita', ''),
(38, 3, 'water issues', ''),
(39, 3, 'loremipsum', ''),
(40, 3, 'unknown name', ''),
(41, 3, 'saqartvelos ganatlebis saministro', '');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `image` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `published_at` varchar(20) NOT NULL,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `image`, `body`, `published_at`, `category`) VALUES
(1, 'Just an empty', 'http://www.salvadori-elettromeccanica.it/images/rame01.jpg', 'Just an empty space. With some color in it (probably not blue but any other color that will be in the logo). However, important updates.', '2011-07-21 11:24', 'project'),
(32, 'vvvvasdqw523', 'http://www.salvadori-elettromeccanica.it/images/rame01.jpg', 'vvvasdq353252352', '2011-07-20 13:00', 'media'),
(35, '3523232362', 'uploads/593276screenshot_opentaps.png', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum', '2011-07-20 12:00', 'project'),
(36, '333333333333333333', 'http://www.salvadori-elettromeccanica.it/images/rame01.jpg', 'sdafdsgsdgsgwe4ry63 74 574574 57457 47', '2011-07-20 11:33', 'adad');

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `district` text NOT NULL,
  `city_town` varchar(255) NOT NULL,
  `grante` varchar(255) NOT NULL,
  `sector` varchar(255) NOT NULL,
  `projects_info` text NOT NULL,
  `logo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `name`, `description`, `district`, `city_town`, `grante`, `sector`, `projects_info`, `logo`) VALUES
(2, 'sdfsfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdfsdfsdfsdf', 'sdfsdfsdfsdfsdsd', 'fsdfsdfsdfsdfsdf', 'sdfsdfsdfsdfsdfdsfsdf', '');

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE IF NOT EXISTS `places` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `longitude` decimal(20,5) NOT NULL,
  `latitude` decimal(20,5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`id`, `longitude`, `latitude`) VALUES
(37, '4921046.04746', '5187570.84658');

-- --------------------------------------------------------

--
-- Table structure for table `project_organizations`
--

CREATE TABLE IF NOT EXISTS `project_organizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `organization_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`,`organization_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `project_organizations`
--

INSERT INTO `project_organizations` (`id`, `project_id`, `organization_id`) VALUES
(9, 3, 2),
(7, 8, 2),
(8, 8, 13);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `budget` int(11) NOT NULL,
  `district` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `grantee` varchar(255) NOT NULL,
  `sector` varchar(255) NOT NULL,
  `start_at` date NOT NULL,
  `end_at` date NOT NULL,
  `info` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `region_id`, `title`, `description`, `budget`, `district`, `city`, `grantee`, `sector`, `start_at`, `end_at`, `info`) VALUES
(1, 6, 'Tskaltubo random project', 'The EBRD is considering providing a 1.5 million loan to Georgia tofinance urgently needed water supply and wastewater improvements in Tskaltubo.At present the city has 2 hours of water supply per day and wastewater is discharged untreated into opendrainage canals. The project will restore reliable water supply and rehabilitate proper wastewater handling.', 122897521, 'Tskaltubo', 'Tskaltubo', 'West Regional Water Company', 'Municipal and enviromental infrastructure', '2010-11-23', '2012-11-23', 'Adjara has been part of Colchis and Caucasian Iberia since ancient times. The EBRD is considering providing a 1.5 million loan to Georgia tofinance urgently needed water supply and wastewater improvements in Tskaltubo.At present the city has 2 hours of water supply per day and wastewater is discharged untreated into opendrainage canals. The project will restore reliable water supply and rehabilitate proper wastewater handling.'),
(3, 6, '1ramee1r', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?', 355614000, 'rame55r', 'rame66r', '77tryrtrrr', 'rame88r ki', '1233-12-19', '1994-06-10', 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?'),
(8, 6, 'aaaaaaaa', 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.', 333333333, 'aaaaaaaa', 'aaaaaaaa', 'aaaaaaaa', 'aaaaaaaa', '3333-11-11', '3333-11-11', 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.');

-- --------------------------------------------------------

--
-- Table structure for table `projects_data`
--

CREATE TABLE IF NOT EXISTS `projects_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `projects_data`
--

INSERT INTO `projects_data` (`id`, `key`, `value`, `project_id`) VALUES
(21, 'aaaaaaaaaaaaa2', 'aaaaaaaaaaaaaaaaaa2', 3),
(23, 'personal5', 'bullets are the beauty of the blistering sky bullets are the beauty of the blistering sky bullets are the beauty of the blistering sky bullets are the beauty of the blistering sky bullets are the beauty of the blistering sky ', 1),
(22, 'ccccccccccc3', 'ccccccccccccccccccc3', 3),
(20, 'bbbbbbbbbbb1', 'bbbbbbbbbbbbbbb1', 3),
(24, 'personal7', 'black holes living in the side of your face black holes living in the side of your face black holes living in the side of your face black holes living in the side of your face ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `raions`
--

CREATE TABLE IF NOT EXISTS `raions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `region_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `raions`
--

INSERT INTO `raions` (`id`, `name`, `region_id`) VALUES
(1, 'dsfsdfsdf', 1),
(2, 'dfsfsdfsdfsdgffgdfgdfg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `region_cordinates`
--

CREATE TABLE IF NOT EXISTS `region_cordinates` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `longitude` decimal(20,5) NOT NULL,
  `latitude` decimal(20,5) NOT NULL,
  `region_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `region_cordinates`
--

INSERT INTO `region_cordinates` (`id`, `longitude`, `latitude`, `region_id`) VALUES
(1, '4636700.30229', '5109299.32963', 6);

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE IF NOT EXISTS `regions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `region_info` text NOT NULL,
  `projects_info` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `population` int(10) NOT NULL,
  `square_meters` int(10) NOT NULL,
  `settlement` varchar(255) NOT NULL,
  `villages` int(10) NOT NULL,
  `districts` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`, `region_info`, `projects_info`, `city`, `population`, `square_meters`, `settlement`, `villages`, `districts`) VALUES
(6, '1test', 'lorem ipsum1', 'lorem ipsum1', 'lorem ipsum1', 343431, 35331, 'lorem ipsum1', 1343, 441);

-- --------------------------------------------------------

--
-- Table structure for table `tag_connector`
--

CREATE TABLE IF NOT EXISTS `tag_connector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `proj_id` int(11) DEFAULT NULL,
  `news_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=125 ;

--
-- Dumping data for table `tag_connector`
--

INSERT INTO `tag_connector` (`id`, `tag_id`, `org_id`, `proj_id`, `news_id`) VALUES
(112, 2, NULL, 1, NULL),
(111, 9, NULL, 8, NULL),
(110, 4, NULL, 8, NULL),
(109, 3, NULL, 8, NULL),
(108, 2, NULL, 8, NULL),
(89, 5, NULL, 3, NULL),
(88, 4, NULL, 3, NULL),
(87, 2, NULL, 3, NULL),
(113, 5, NULL, 1, NULL),
(114, 6, NULL, 1, NULL),
(115, 9, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`) VALUES
(1, 'lorem'),
(2, 'ipsum'),
(3, 'dolor'),
(4, 'sit'),
(5, 'amet'),
(6, 'consectetur'),
(9, 'vaxaxa3'),
(10, 'tag#');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'vazha', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8'),
(2, 'client', '2736fab291f04e69b62d490c3c09361f5b82461a');
