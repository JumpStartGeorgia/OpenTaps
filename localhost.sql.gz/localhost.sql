-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 22, 2011 at 02:36 PM
-- Server version: 5.1.54
-- PHP Version: 5.3.5-1ubuntu7.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `opentaps`
--
CREATE DATABASE `opentaps` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `opentaps`;

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE IF NOT EXISTS `donors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `don_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `don_desc` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`id`, `don_name`, `don_desc`) VALUES
(2, '4545454', 'vaxaxaxa'),
(5, '44444444444444444444444444444444444444444', '444444444444444444444444444444444444444444124124521421351235 1235 2135 234 235 2352352 3'),
(6, 'adsdasdas', 'dasdsadasdasd'),
(7, 'sdasdasd', 'asdasda'),
(8, 'asdasdasd', 'dasdasdad'),
(9, 'asdasdasd', 'dasdasdad'),
(10, 'asdasdasd', 'dasdasdad');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `short_name` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `parent_id`, `name`, `short_name`) VALUES
(1, 0, 'georgia profile', 'profile'),
(2, 0, 'water issues', 'issues'),
(3, 0, 'projects', 'projects'),
(4, 0, 'organizations', 'org'),
(5, 0, 'statistics', 'stat'),
(6, 0, 'data', 'data'),
(7, 1, 'submenu1', ''),
(8, 1, 'submenu2', ''),
(9, 4, 'organization1', ''),
(10, 4, 'organization2', ''),
(11, 3, 'project1', ''),
(12, 1, 'project2f', ''),
(23, 0, 'sadfsa', '');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `image` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `published_at` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `image`, `body`, `published_at`) VALUES
(1, 'Just an empty', '', 'Just an empty space. With some color in it (probably not blue but any other color that will be in the logo). However, important updates.', '2011-07-21 11:24'),
(32, 'vvvvasdqw523', '', 'vvvasdq353252352', '2011-07-20 13:00'),
(35, '3523232362', 'uploads/593276screenshot_opentaps.png', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum', '2011-07-20 12:00'),
(36, '333333333333333333', '', 'sdafdsgsdgsgwe4ry63 74 574574 57457 47', '2011-07-20 11:33');

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `org_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `org_description` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `org_name`, `org_description`) VALUES
(2, 'vazha organization', 'nothing special.'),
(13, 'irakli organization', 'Provides people with everything.');

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE IF NOT EXISTS `places` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `longitude` decimal(20,5) NOT NULL,
  `latitude` decimal(20,5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`id`, `longitude`, `latitude`) VALUES
(37, '4921046.04746', '5187570.84658');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `description`) VALUES
(1, 'projec13', 'nothing special'),
(4, 'sdasdasda', '4352347247das');

-- --------------------------------------------------------

--
-- Table structure for table `projects_data`
--

CREATE TABLE IF NOT EXISTS `projects_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `projects_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `tag_connector`
--

CREATE TABLE IF NOT EXISTS `tag_connector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `proj_id` int(11) NOT NULL,
  `don_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=108 ;

--
-- Dumping data for table `tag_connector`
--

INSERT INTO `tag_connector` (`id`, `tag_id`, `org_id`, `proj_id`, `don_id`) VALUES
(1, 1, 0, 0, 2),
(2, 2, 0, 0, 2),
(3, 5, 0, 0, 2),
(15, 9, 0, 0, 10),
(107, 10, 0, 1, 0),
(99, 10, 2, 0, 0),
(98, 9, 2, 0, 0),
(97, 6, 2, 0, 0),
(96, 5, 2, 0, 0),
(95, 4, 2, 0, 0),
(94, 3, 2, 0, 0),
(93, 1, 2, 0, 0),
(68, 9, 9, 0, 0),
(67, 1, 9, 0, 0),
(92, 10, 13, 0, 0),
(91, 9, 13, 0, 0),
(90, 6, 13, 0, 0),
(106, 4, 0, 1, 0),
(105, 2, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`) VALUES
(1, 'lorem'),
(2, 'ipsum'),
(3, 'dolor'),
(4, 'sit'),
(5, 'amet'),
(6, 'consectetur'),
(9, 'vaxaxa3'),
(10, 'tag#');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'vazha', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8'),
(2, 'client', '2736fab291f04e69b62d490c3c09361f5b82461a');
